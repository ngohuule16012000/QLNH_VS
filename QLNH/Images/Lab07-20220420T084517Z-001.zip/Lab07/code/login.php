<?php

$user_name = $_POST["username"];
$password = $_POST["password"];

if ( (! isset ($user_name)) || (! isset ($password)) ||
   ($user_name != 'admin@gmail.com') || ($password != '123456') ) {
    echo "Hello";
    die ("Email hoặc mật khẩu không đúng");
}

header("Location: /home.html");
exit;
?>